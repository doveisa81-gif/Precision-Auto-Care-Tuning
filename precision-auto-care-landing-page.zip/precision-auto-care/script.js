// Precision Auto Care & Tuning — interactions
const serviceDetails = {
  brakes: {
    title: "Brake Service",
    description: "Your braking system is your first line of safety. We inspect the complete system, explain what we find, and recommend only the work your vehicle needs.",
    items: ["Brake pad and rotor inspection", "Caliper, hose and brake-line checks", "Brake fluid condition assessment", "Road test and post-service verification"]
  },
  engine: {
    title: "Engine Diagnostics",
    description: "A warning light is a starting point, not a diagnosis. Our technicians use professional scan tools and hands-on testing to track down the underlying issue.",
    items: ["Computerized fault-code scan", "Live data and component testing", "Clear explanation of findings", "Repair options prioritized by urgency"]
  },
  oil: {
    title: "Oil Changes",
    description: "Fresh oil helps protect critical engine components. We match the oil and filter to your vehicle's specifications and check key maintenance items while your car is here.",
    items: ["Correct-grade oil and quality filter", "Fluid and leak visual checks", "Tire pressure and basic safety check", "Maintenance reminder reset where applicable"]
  },
  transmission: {
    title: "Transmission Repair",
    description: "Slipping, delayed engagement, unusual noises or fluid leaks deserve a careful assessment. We inspect the symptoms and discuss practical next steps before repairs begin.",
    items: ["Transmission fluid and leak inspection", "Shift-quality and road-test assessment", "Electronic diagnostics where applicable", "Written estimate before approved repairs"]
  }
};

const modal = document.getElementById("service-modal");
const modalTitle = document.getElementById("modal-title");
const modalDescription = document.getElementById("modal-description");
const modalList = document.getElementById("modal-list");
const closeModalButton = document.querySelector(".modal-close");
let lastFocusedElement = null;

function openServiceModal(key) {
  const service = serviceDetails[key];
  if (!service) return;
  lastFocusedElement = document.activeElement;
  modalTitle.textContent = service.title;
  modalDescription.textContent = service.description;
  modalList.replaceChildren(...service.items.map(item => {
    const li = document.createElement("li");
    li.textContent = item;
    return li;
  }));
  modal.classList.add("is-visible");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  closeModalButton.focus();
}
function closeServiceModal() {
  modal.classList.remove("is-visible");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  if (lastFocusedElement) lastFocusedElement.focus();
}

document.querySelectorAll(".service-card").forEach(card => {
  card.addEventListener("click", () => openServiceModal(card.dataset.service));
});
closeModalButton.addEventListener("click", closeServiceModal);
modal.addEventListener("click", event => {
  if (event.target === modal) closeServiceModal();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && modal.classList.contains("is-visible")) closeServiceModal();
});

const quoteForm = document.getElementById("quote-form");
const quoteMessage = document.getElementById("quote-message");
quoteForm.addEventListener("submit", event => {
  event.preventDefault();
  const service = document.getElementById("service-select").value;
  const vehicle = document.getElementById("vehicle-input").value.trim();
  if (!service || !vehicle) {
    quoteMessage.textContent = "Please choose a service and enter your vehicle details.";
    quoteMessage.style.color = "#c91828";
    return;
  }
  quoteMessage.style.color = "#18804c";
  quoteMessage.textContent = `Thanks! Your ${service.toLowerCase()} request for ${vehicle} is ready. Connect this form to your booking system to receive submissions.`;
});

// Demo shop hours use the visitor's local browser time.
// Change these values to match the garage's actual local schedule.
function updateShopStatus() {
  const now = new Date();
  const day = now.getDay(); // 0 = Sunday
  const minutes = now.getHours() * 60 + now.getMinutes();
  const isWeekday = day >= 1 && day <= 5;
  const isSaturday = day === 6;
  const open = (isWeekday && minutes >= 8 * 60 && minutes < 18 * 60) ||
               (isSaturday && minutes >= 9 * 60 && minutes < 14 * 60);

  const status = document.getElementById("open-status-text");
  const detail = document.getElementById("open-status-detail");
  const indicator = document.querySelector(".open-status");
  status.textContent = open ? "OPEN NOW" : "CLOSED";
  detail.textContent = open ? "We're ready to help" : "See you during our next business hours";
  indicator.classList.toggle("is-open", open);
  indicator.classList.toggle("is-closed", !open);
}
updateShopStatus();
setInterval(updateShopStatus, 60 * 1000);
document.getElementById("year").textContent = new Date().getFullYear();

// Mobile navigation
const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("is-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

// Modal booking CTA closes the modal and returns to the quote form.
document.querySelector(".modal-book").addEventListener("click", () => {
  closeServiceModal();
});
